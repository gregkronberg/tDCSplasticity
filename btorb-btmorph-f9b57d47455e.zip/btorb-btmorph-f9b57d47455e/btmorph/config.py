# default color scheme
c_scheme_default = {'bg': 'white','neurite':['r','g','b','c','m','y','k','g','DarkGray']}

# neuromorpho.org color scheme
c_scheme_nm = {'bg': 'black','neurite':['red','gray','lightgreen','magenta','cyan','cyan','cyan']}

