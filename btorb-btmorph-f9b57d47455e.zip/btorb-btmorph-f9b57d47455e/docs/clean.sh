rm -Rf btmorph
rm -Rf _build
